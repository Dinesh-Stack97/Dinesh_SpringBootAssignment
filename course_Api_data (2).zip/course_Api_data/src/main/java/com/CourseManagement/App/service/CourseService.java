package com.CourseManagement.App.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.CourseManagement.App.Entity.courseManagement;
import com.CourseManagement.App.Repositery.CourseManagementRepositery;

@Service
public class CourseService {
	
	@Autowired
	private CourseManagementRepositery courseManagementRepo;
	
	private List<courseManagement> courses = new ArrayList<>(Arrays.asList(
	           new courseManagement("Spring","Spring Framework","Spring_Frmework Description",25000),
	           new courseManagement("Java","core java","Core Java Description",25000),
                new courseManagement("JDBC"," Hibernate Framework","hibernate_Frmework Description",25000),
       	new courseManagement("Spring","Structs Framework","Structs_Frmework Description",25000),
	             new courseManagement("Spring_IOc","Spring Bootk","Spring_Frmework Description",25000)));

public List<courseManagement> getAllCourse(){
	
	//return topics;
	List<courseManagement> courses = new ArrayList<>();
	courseManagementRepo.findAll()
	.forEach(courses::add);
	return courses;
	
}

public courseManagement getCourseManagement(String CourseId)
{
 	//return course.stream().filter(t -> t.getCourseId().equals(CourseId)).findFirst().get();
	return courseManagementRepo.findById(CourseId).get();
}

public void addcourse(@RequestBody courseManagement course) {
	// TODO Auto-generated method stub
	courseManagementRepo.save(course);
	
	
}

public void updatecourse(String id, courseManagement course) {
	// TODO Auto-generated method stub
	
	courseManagementRepo.save(course);
	
	
}

public void delteTopic(String CourseId) {
	// TODO Auto-generated method stub
	courseManagementRepo.deleteById(CourseId);
}
}

	

