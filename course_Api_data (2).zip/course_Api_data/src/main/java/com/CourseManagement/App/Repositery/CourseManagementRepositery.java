package com.CourseManagement.App.Repositery;

import org.springframework.data.repository.CrudRepository;

import com.CourseManagement.App.Entity.courseManagement;

public interface CourseManagementRepositery extends CrudRepository<courseManagement, String>
{

	
	
	
	//getAllCourse
	
	//getCoruseById

}
